<?php

function getMembers()
{
    $ci = &get_instance();
    $ci->load->database();
    $data = $ci->db->select('mem_id,first_name,last_name')->from('tbl_members')->get()->result();
    echo '<option value="">-- Select a member  --</option>';
    foreach ($data as $dd) {
        echo '<option value="' . $dd->mem_id . '" >  ' . $dd->first_name .' '.$dd->last_name. '</option><br />';
    }
}


function getAllCountryList()
{
    $ci =& get_instance();
    $ci->load->database();
    $data = $ci->db->select('*')->from('countries')->get()->result();

    foreach ($data as $d) {
        echo '<option value="' . $d->id . '" />  ' . $d->con_name . '<br />';
    }


}

function getAllStatesByCountryId($country_id)
{
    $ci =& get_instance();
    $ci->load->database();
    $data = $ci->db->select('*')->from('states')->where('country_id', $country_id)->get()->result();
    $out = '';
    foreach ($data as $dd) {
        $out .= '<option value="' . $dd->id . '" >  ' . $dd->st_name . '</option><br />';
    }
    echo empty($out) ? 'Not Set' : $out;
}

function generatePaymentMethod($val){
	
	switch ($val) {
		case 1:
			echo "By Cash";
			break;
		case 2:
			echo "bKash";
			break;
		case 3:
			echo "Debit Card";
			break;
		case 4:
			echo "Credit Card";
			break;
		case 5:
			echo "DBBL";
			break;
		default:
			echo "";
	}
}