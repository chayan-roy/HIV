<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

//session_start();

class super_admin extends Base_Controller {

    // public function __construct() {
    //     parent::__construct();
    //     $admin_id = $this->session->userdata('admin_id');
    //     if ($admin_id == NULL) {
    //         redirect('admin');
    //     }
    // }

    public function __construct() {
        parent:: __construct();
        error_reporting(0);

        $admin_id = $this->session->userdata('admin_id');
        if ($admin_id == NULL) {
            redirect('welcome');
        }

        //  $this->load->model("user_model");
        $this->load->helper('user_helper');
    }

    public function index() {
        $data = array();
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "hiv_management";
        try {
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }

        //$data['stmt'] = $this->super_admin_model->select_all_category11();
        //$stmt = $conn->query("SELECT * FROM tbl_hiv_patient");
        $stmt = $this->super_admin_model->select_all_category11();
        $products = [];
        foreach ($stmt as $rw) {
            $products[] = array(
                'name' => $rw->name,
                'pregnancy' => $rw->pregnancy,
                'gender' => $rw->gender,
                'hypertension' => $rw->hypertension,
                'notify24hours' => $rw->notify24hours,
                'diabetes' => $rw->diabetes,
                'on_ipt' => $rw->on_ipt,
                'test_refused' => $rw->test_refused,
                'hiv_status' => $rw->hiv_status
            );
            //echo $rw['art_start'];
        }
        $data['products'] = ($products);
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['all_beton_vata'] = $this->super_admin_model->select_all_beton_vata();
        // $data['all_customer_details'] = $this->super_admin_model->select_all_category();
        $data['all_product_list_price'] = $this->db->select('*')->from('tbl_dealer_product')->get()->result();

        $data['admin_maincontent'] = $this->load->view('admin/dashboard', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function initChart() {

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "hiv_management";
        try {
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }

        //$data['stmt'] = $this->super_admin_model->select_all_category11();
        //$stmt = $conn->query("SELECT * FROM tbl_hiv_patient");
        $stmt = $this->super_admin_model->select_all_category11();
        $products = [];
        foreach ($stmt as $rw) {
            $products[] = array(
                'name' => $rw->name,
                'hiv_patient_id' => $rw->hiv_patient_id,
                'kinphonenumber' => $rw->kinphonenumber,
                'kinname' => $rw->kinname,
                'hiv_status' => $rw->hiv_status,
                'ipt_start' => $rw->ipt_start,
                'art_start' => $rw->art_start
            );
            //echo $rw['art_start'];
        }
        $data['products'] = ($products);
        //$this->load->view('chart', $data);
        $data['admin_maincontent'] = $this->load->view('admin/dashboard', $data, true);
        //$this->load->view('admin/chart', $data);
        $this->load->view('admin/chart', $data);
    }

    public function logout() {
        $this->session->unset_userdata('admin_id');
        $this->session->unset_userdata('admin_name');
        //$sdata['message'] = "Successfully logout";
        //$this->session->set_userdata($sdata);
        redirect('welcome');
    }

    public function download_pdf_details($hiv_patient_id) {
        $data = array();
        $this->load->library('pdf');
        $data['customer_info'] = $this->super_admin_model->select_customer_data_by_id($hiv_patient_id);
        //$data['all_product_details'] = $this->super_admin_model->select_all_category();
        $html = $this->load->view('admin/pdfview', $data, true);
        $this->pdf->createPDF($html, 'Patient_details', false);
        
    }

    public function view_user_profile($admin_id) {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['user_info'] = $this->super_admin_model->select_user_profile_data_by_id($admin_id);
        //$data['customer_info'] = $this->super_admin_model->select_customer_by_id($customer_id);
        $data['admin_maincontent'] = $this->load->view('admin/view_profile', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function edit_user_profile($admin_id) {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['product_info'] = $this->super_admin_model->select_all_user_by_id($admin_id);
        //$data['customer_info'] = $this->super_admin_model->select_customer_by_id($customer_id);
        $data['admin_maincontent'] = $this->load->view('admin/edit_user_profile', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function add_customer() {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['admin_maincontent'] = $this->load->view('admin/add_customer', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function data_analytic() {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        //$data['all_customer_details'] = $this->super_admin_model->select_all_category();
        //$data['all_order_by_date'] = $this->db->select('*')->from('tbl_order_book')->join('tbl_product', 'tbl_product.product_id = tbl_order_book.product_id')->get()->result();
        $data['all_product_details'] = $this->super_admin_model->select_all_category();
        $data['admin_maincontent'] = $this->load->view('admin/data_analytic', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function add_user() {

        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['admin_maincontent'] = $this->load->view('admin/add_user', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function add_index($hiv_patient_id) {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['customer_info1'] = $this->db->select('*')->from('tbl_hiv_patient')->where('hiv_patient_id', $hiv_patient_id)->get()->row();
        $data['admin_maincontent'] = $this->load->view('admin/add_index', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }
    

    public function index_contact_list() {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['admin_maincontent'] = $this->load->view('admin/add_index_contact_list', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function treatmentvisit($hiv_patient_id) {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['customer_info'] = $this->db->select('*')->from('tbl_hiv_patient')->where('hiv_patient_id', $hiv_patient_id)->get()->row();
        $data['admin_maincontent'] = $this->load->view('admin/add_treatment', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function linkage_to_care_patient($hiv_patient_id) {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['customer_info'] = $this->db->select('*')->from('tbl_hiv_patient')->where('hiv_patient_id', $hiv_patient_id)->get()->row();
        $data['admin_maincontent'] = $this->load->view('admin/add_dealer_product', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function testing($hiv_patient_id) {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['customer_info'] = $this->db->select('*')->from('tbl_hiv_patient')->where('hiv_patient_id', $hiv_patient_id)->get()->row();
        $data['admin_maincontent'] = $this->load->view('admin/add_testing', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function consent_form($hiv_patient_id) {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['customer_info'] = $this->db->select('*')->from('tbl_hiv_patient')->where('hiv_patient_id', $hiv_patient_id)->get()->row();
        $data['admin_maincontent'] = $this->load->view('admin/add_consent', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function defaulter($hiv_patient_id) {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['customer_info'] = $this->db->select('*')->from('tbl_hiv_patient')->where('hiv_patient_id', $hiv_patient_id)->get()->row();
        $data['admin_maincontent'] = $this->load->view('admin/add_defaulter', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function awaiting_on_art($hiv_patient_id) {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['customer_info'] = $this->db->select('*')->from('tbl_hiv_patient')->where('hiv_patient_id', $hiv_patient_id)->get()->row();
        $data['admin_maincontent'] = $this->load->view('admin/awaiting_on_art', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function add_dealer_product() {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['get_product'] = $this->db->select('*')->from('tbl_product')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/add_dealer_product', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function print_data() {
        $data = array();
        $data['admin_maincontent'] = $this->load->view('admin/print_data', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function search_data_by_date($area) {
        $data = array();
        $data['all_kisti_by_date'] = $this->super_admin_model->select_all_kisti_by_date($area);
        // $data['all_kisti_info_by_date'] = $this->db->select('*')->from('tbl_kisti_soncoy')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/print_data', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function print_area2() {
        $data = array();
        $data['all_kisti_info_by_date'] = $this->db->select('*')->from('tbl_kisti_soncoy')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/print_area2', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function update_sonchoy($customer_id) {
        $data = array(
            'customer_id' => $customer_id,
            'soncoy' => $this->input->post('soncoy'),
            'kisti' => $this->input->post('kisti')
        );
        $this->super_admin_model->update_customer_soncoy_data($data, $customer_id);
        redirect('super_admin/manage_area2');
        // $this->cart->update($data);
        // redirect('checkout/show_cart');
    }

    public function active_dealer_product($dealer_product_id) {

        $this->super_admin_model->publish_dealer_product_by_id($dealer_product_id);
        redirect('super_admin/manage_dealer_product');
    }

    public function activate_customer_details($hiv_patient_id) {

        $this->super_admin_model->publish_patient_details($hiv_patient_id);
        redirect('super_admin/manage_customer_suprovat');
    }

    public function deactivate_customer_details($hiv_patient_id) {

        $this->super_admin_model->unpublish_patient_details($hiv_patient_id);
        redirect('super_admin/manage_customer_suprovat');
    }

    public function deactive_dealer_product($dealer_product_id) {

        $this->super_admin_model->unpublish_dealer_product_by_id($dealer_product_id);
        redirect('super_admin/manage_dealer_product');
    }

    public function send_sms1() {
        $data = array();
        $data['admin_maincontent'] = $this->load->view('admin/send_sms', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function save_soncoy_data() {

        $customer_id = $this->input->post('customer_id[]');
        $client_id_no = $this->input->post('client_id_no[]');
        $kisti = $this->input->post('kisti[]');
        $soncoy = $this->input->post('soncoy[]');

        for ($i = 0; $i < count($kisti); $i++) {

            $data1 = array(
                'customer_id' => $customer_id[$i],
                'client_id_no' => $client_id_no[$i],
                'kisti' => $kisti[$i],
                'soncoy' => $soncoy[$i]
            );
            // print_r($data1);
            // exit();

            $query = $this->super_admin_model->insertkisty($data1);
        }
        if ($query) {
            echo "save successful";
        } else {
            echo "failed to save";
        }

        //}//for
    }

    public function search_data() {

        $from = $this->input->post('from_date');
        $to = $this->input->post('to_date');

        $data['search_datachayan'] = $this->db->select('*')->from('tbl_hiv_patient')->where('date >=', $from)->where('date <= ', $to)->get()->result();

        //$data['search_total_price'] = $this->super_admin_model->search_data($from, $to);
        //$data['search_total_dealer_price'] = $this->super_admin_model->search_total_dealer_price($from, $to);
        //$data['search_total_shop_price'] = $this->super_admin_model->search_total_shop_price($from, $to);
        //$data['search_dealer_invest_total_taka'] = $this->super_admin_model->search_dealer_invest_total_taka($from, $to);
        // $data['search_dokandarer_ponner_total_taka'] = $this->super_admin_model->search_dokandarer_ponner_total_taka($from, $to);
// $this->db->select_sum('total_lav');
//  //$this->db->where('area', 1);
// $this->db->where('order_date >=', '2020-02-24');
// $this->db->where('order_date <=', '2020-02-24');
// $result = $this->db->get('tbl_order_book')->row();
// //print_r($result);
//  echo $d= $result->total_lav ." টাকা";
// $data['cccccccc'] = $this->db->select('total_lav')->from('tbl_order_book')->where('order_date >=', $from)->where('order_date <= ',$to)->get()->row();
// echo "string". $cccccccc;
        //$data['chayanrr'] = $this->db->select_sum('total_lav')->where('order_date >=', $from)->where('order_date <= ', $to)->get('tbl_order_book')->row();
        $products = [];
        foreach ($data['search_datachayan'] as $rw) {
            $products[] = array(
                'name' => $rw->name,
                'pregnancy' => $rw->pregnancy,
                'gender' => $rw->gender,
                'hypertension' => $rw->hypertension,
                'notify24hours' => $rw->notify24hours,
                'diabetes' => $rw->diabetes,
                'on_ipt' => $rw->on_ipt,
                'test_refused' => $rw->test_refused,
                'hiv_status' => $rw->hiv_status
            );
            //echo $rw['art_start'];
        }
        $data['products'] = ($products);

        $data['admin_maincontent'] = $this->load->view('admin/filter', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function search_data_by_age() {
        $data = array();

        $hiv_status = $this->input->post('hiv_status');
        $gender = $this->input->post('gender');
        $notify24hours = $this->input->post('notify24hours');
        $recent_test_result = $this->input->post('recent_test_result');
        $patient_age = $this->input->post('patient_age');
        //$patient_age1 = $this->input->post('patient_age1');
        $patient_age2 = $this->input->post('patient_age2');
        $as=100;
       $data['search_datachayan'] = $this->db->select('*')->from('tbl_hiv_patient')->where("patient_age BETWEEN '$patient_age' AND '100'")->get()->result();

       
        $products = [];
        foreach ($data['search_datachayan'] as $rw) {
            $products[] = array(
                'name' => $rw->name,
                'pregnancy' => $rw->pregnancy,
                'gender' => $rw->gender,
                'hypertension' => $rw->hypertension,
                'notify24hours' => $rw->notify24hours,
                'diabetes' => $rw->diabetes,
                'on_ipt' => $rw->on_ipt,
                'test_refused' => $rw->test_refused,
                'hiv_status' => $rw->hiv_status
            );
            //echo $rw['art_start'];
        }
        $data['products'] = ($products);

        $data['admin_maincontent'] = $this->load->view('admin/filter', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }
    public function search_data_by_radio_button() {
        $data = array();
//        $servername = "localhost";
//        $username = "root";
//        $password = "";
//        $dbname = "hiv_management";
//        try {
//            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
//            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//        } catch (PDOException $e) {
//            echo $e->getMessage();
//        }
//
//        //$data['stmt'] = $this->super_admin_model->select_all_category11();
//        //$stmt = $conn->query("SELECT * FROM tbl_hiv_patient");
//        $stmt = $this->super_admin_model->select_all_category11();
//        $products = [];
//        foreach ($stmt as $rw) {
//            $products[] = array(
//                'name' => $rw->name,
//                'pregnancy' => $rw->pregnancy,
//                'gender' => $rw->gender,
//                'hypertension' => $rw->hypertension,
//                'notify24hours' => $rw->notify24hours,
//                'diabetes' => $rw->diabetes,
//                'on_ipt' => $rw->on_ipt,
//                'test_refused' => $rw->test_refused,
//                'hiv_status' => $rw->hiv_status
//            );
//            //echo $rw['art_start'];
//        }
//        $data['products'] = ($products);
        $hiv_status = $this->input->post('hiv_status');
        $gender = $this->input->post('gender');
        $notify24hours = $this->input->post('notify24hours');
        $recent_test_result = $this->input->post('recent_test_result');
        $patient_age = $this->input->post('patient_age');
       //$patient_age2 = $this->input->post('patient_age2');
        //$gender = $this->input->post('gender'); //or_where('hiv_status =', $hiv_status)->or_where('notify24hours =', $notify24hours)->
//        if (isset($patient_age2)){
//        $multiClause =('patient_age' >= $patient_age2);
//        }
        $data['search_datachayan'] = $this->db->select('*')->from('tbl_hiv_patient')->where("hiv_status =", $hiv_status)->or_where('gender =', $gender)->or_where('notify24hours =', $notify24hours)->or_where('recent_test_result =', $recent_test_result)->get()->result();

        //$stmt = $this->super_admin_model->select_all_category11();
        $products = [];
        foreach ($data['search_datachayan'] as $rw) {
            $products[] = array(
                'name' => $rw->name,
                'pregnancy' => $rw->pregnancy,
                'gender' => $rw->gender,
                'hypertension' => $rw->hypertension,
                'notify24hours' => $rw->notify24hours,
                'diabetes' => $rw->diabetes,
                'on_ipt' => $rw->on_ipt,
                'test_refused' => $rw->test_refused,
                'hiv_status' => $rw->hiv_status
            );
            //echo $rw['art_start'];
        }
        $data['products'] = ($products);

        $data['admin_maincontent'] = $this->load->view('admin/filter', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function update_sonchoy_area1($customer_id) {
        $data = array(
            'customer_id' => $customer_id,
            'soncoy' => $this->input->post('soncoy'),
            'kisti' => $this->input->post('kisti')
        );
        $this->super_admin_model->update_customer_soncoy_data($data, $customer_id);
        redirect('super_admin/manage_area1');
        // $this->cart->update($data);
        // redirect('checkout/show_cart');
    }

    public function update_sonchoy2($customer_id) {
        $data = array(
            'customer_id' => $customer_id,
            'soncoy' => $this->input->post('soncoy'),
            'kisti' => $this->input->post('kisti')
        );
        $this->super_admin_model->update_customer_soncoy_data($data, $customer_id);
        redirect('super_admin/manage_customer_area2');
        // $this->cart->update($data);
        // redirect('checkout/show_cart');
    }

    public function update_kisti($customer_id) {
        $data = array(
            'customer_id' => $customer_id,
            'kisti' => $this->input->post('kisti')
        );
        $this->super_admin_model->update_customer_kisti_data($data, $customer_id);
        redirect('super_admin/manage_area2');
        // $this->cart->update($data);
        // redirect('checkout/show_cart');
    }

    public function update_kisti121($customer_id) {
        $data = array(
            'customer_id' => $customer_id,
            'kisti' => $this->input->post('kisti')
        );
        $this->super_admin_model->update_customer_kisti_data($data, $customer_id);
        redirect('super_admin/manage_category');
        // $this->cart->update($data);
        // redirect('checkout/show_cart');
    }

    public function update_kisti1($customer_id) {
        $data = array(
            'customer_id' => $customer_id,
            'kisti' => $this->input->post('kisti')
        );
        $this->super_admin_model->update_customer_kisti_data($data, $customer_id);
        redirect('super_admin/manage_customer_area1');
        // $this->cart->update($data);
        // redirect('checkout/show_cart');
    }

    public function update_kisti_area1($customer_id) {
        $data = array(
            'customer_id' => $customer_id,
            'kisti' => $this->input->post('kisti')
        );
        $this->super_admin_model->update_customer_kisti_data($data, $customer_id);
        redirect('super_admin/manage_area1');
        // $this->cart->update($data);
        // redirect('checkout/show_cart');
    }

    public function update_kisti2($customer_id) {
        $data = array(
            'customer_id' => $customer_id,
            'kisti' => $this->input->post('kisti')
        );
        $this->super_admin_model->update_customer_kisti_data($data, $customer_id);
        redirect('super_admin/manage_customer_area2');
        // $this->cart->update($data);
        // redirect('checkout/show_cart');
    }

    public function save_customer() {

        $data = array();

        $config['upload_path'] = './images/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = 9900;
        $config['max_width'] = 9900;
        $config['max_height'] = 9900;
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('customer_image')) {
            $error = array('error' => $this->upload->display_errors());

            $this->load->view('super_admin/index', $error);
        } else {
            $config['source_image'] = $this->upload->upload_path . $this->upload->file_name;
            $fdata = $this->upload->data();
            $data['customer_image'] = base_url() . $config['upload_path'] . $fdata['file_name'];
            $data['name'] = $this->input->post('name');
            $data['gender'] = $this->input->post('gender');
            $data['identifynumber'] = $this->input->post('identifynumber');
            $data['patient_age'] = $this->input->post('patient_age');
            $data['patientphonenumber'] = $this->input->post('patientphonenumber');
            $data['address'] = $this->input->post('address');
            $data['kinname'] = $this->input->post('kinname');
            $data['kinphonenumber'] = $this->input->post('kinphonenumber');
            $data['kinaddress'] = $this->input->post('kinaddress');
            $data['relationship'] = $this->input->post('relationship');
            $data['patient_value'] = $this->input->post('patient_value');
            $data['treatment_start_date'] = $this->input->post('treatment_start_date');
            $data['hiv_status'] = $this->input->post('hiv_status');
            $data['last_hiv_test_date'] = $this->input->post('last_hiv_test_date');

            $this->super_admin_model->save_customer_data($data);
            $sdata = array();
            $sdata['message'] = "Successfully Added Patient";
            $this->session->set_userdata($sdata);
            redirect('super_admin/add_customer');
        }
    }

    public function save_user() {
        $data = array();
        $data['admin_name'] = $this->input->post('admin_name');
        $data['user_identify_number'] = $this->input->post('user_identify_number');
        $data['phone_number'] = $this->input->post('phone_number');
        $data['company_number'] = $this->input->post('company_number');
        $data['designation'] = $this->input->post('designation');
        $data['location'] = $this->input->post('location');
        $data['password'] = $this->input->post('password');
        $data['admin_email_address'] = $this->input->post('admin_email_address');
        $data['access_label'] = $this->input->post('access_label');

        $this->super_admin_model->save_hiv_user_data($data);
        $sdata = array();
        $sdata['message'] = "Successfully Added User";
        $this->session->set_userdata($sdata);
        redirect('super_admin/add_user');
    }

    public function save_index() {

        $data = array();

        //$hiv_patient_id = $this->input->post('hiv_patient_id');

        $data['index_name'] = $this->input->post('index_name');
        $data['hiv_patient_id'] = $this->input->post('hiv_patient_id');
        $data['index_gender'] = $this->input->post('index_gender');
        $data['index_identifynumber'] = $this->input->post('index_identifynumber');
        $data['index_patientphonenumber'] = $this->input->post('index_patientphonenumber');
        $data['index_address'] = $this->input->post('index_address');
        $data['index_patient_care'] = $this->input->post('index_patient_care');
        $data['index_age'] = $this->input->post('index_age');
        $data['index_slip'] = $this->input->post('index_slip');
        $data['index_partner_name'] = $this->input->post('index_partner_name');
        $data['index_partner_identify_number'] = $this->input->post('index_partner_identify_number');
        $data['index_partner_contact_number'] = $this->input->post('index_partner_contact_number');
        $data['index_partner_physical_address'] = $this->input->post('index_partner_physical_address');
        $data['index_partner_gender'] = $this->input->post('index_partner_gender');
        $data['index_partner_age'] = $this->input->post('index_partner_age');
        $data['index_positve_yes_no'] = $this->input->post('index_positve_yes_no');
        $data['index_unknown'] = $this->input->post('index_unknown');
        $data['index_hct_outcome'] = $this->input->post('index_hct_outcome');
        $data['index_text_date_time'] = $this->input->post('index_text_date_time');
        $data['index_test_result'] = $this->input->post('index_test_result');
        $data['index_comments'] = $this->input->post('index_comments');
//       print_r($data);
//       exit();
        $this->super_admin_model->save_index_data($data);
        $sdata = array();
        $sdata['message'] = "Successfully Added Index";
        $this->session->set_userdata($sdata);
        redirect('super_admin/manage_index');
    }

    public function save_contact_list() {
        $data = array();
//        $data['age_detarmine'] = $this->input->post('age_detarmine');
//        $data['contact_name'] = $this->input->post('contact_name');
//        $data['date_bod'] = $this->input->post('date_bod');
//        $data['gender'] = $this->input->post('gender');
//        $data['address'] = $this->input->post('address');
        $age_detarmine = implode(',', $this->input->post('age_detarmine'));

        $contact_name = implode(',', $this->input->post('contact_name'));
        print_r($contact_name);
        exit();
        $date_bod = implode(',', $this->input->post('date_bod'));
        $gender = implode(',', $this->input->post('gender'));
        $address = implode(',', $this->input->post('address'));
        $available = implode(',', $this->input->post('available'));

        $form_data = array(
            'first_name' => $this->input->post('first_name'),
            'last_name' => $this->input->post('last_name'),
            'phone' => $phone
        );
        $this->super_admin_model->save_contact_list($data);
        $sdata = array();
        $sdata['message'] = "Successfully Added Index";
        $this->session->set_userdata($sdata);
        redirect('super_admin/add_index');
    }

    public function baki() {
        $data = array();
        $data['admin_maincontent'] = $this->load->view('admin/baki', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function shop_baki_entry() {
        $data = array();
        $data['get_dokandar'] = $this->db->select('*')->from('tbl_baki')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/shop_baki_entry', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function save_dokandarer_baki() {
        $data = array();
        $data['dokandarer_id'] = $this->input->post('dokandarer_id');
        $data['memo_serial'] = $this->input->post('memo_serial');
        $data['total_price'] = $this->input->post('total_price');
        $data['joma'] = $this->input->post('joma');
        // $data['product_shop_price'] = $this->input->post('product_shop_price');
        // print_r($data);
        // exit();
        $this->super_admin_model->save_dokandarer_baki($data);
        $sdata = array();
        $sdata['message'] = "Successfully Added";
        $this->session->set_userdata($sdata);
        redirect('super_admin/shop_baki_entry');
    }

    public function save_baki() {
        $data = array();
        $data['shop_name'] = $this->input->post('shop_name');
        $data['maliker_name'] = $this->input->post('maliker_name');
        $data['market_name'] = $this->input->post('market_name');
        $data['mobile_number'] = $this->input->post('mobile_number');
        // $data['product_shop_price'] = $this->input->post('product_shop_price');
        // print_r($data);
        // exit();
        $this->super_admin_model->save_baki($data);
        $sdata = array();
        $sdata['message'] = "Successfully Added";
        $this->session->set_userdata($sdata);
        redirect('super_admin/baki');
    }

    public function manage_dokandar() {
        $data = array();
        $data['all_dokandar'] = $this->super_admin_model->select_all_dokandar();
        $data['admin_maincontent'] = $this->load->view('admin/manage_dokandar', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function manage_user() {
        $data = array();
        $data['all_user'] = $this->super_admin_model->select_all_user2();
        $data['admin_maincontent'] = $this->load->view('admin/manage_user', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function manage_index() {
        $data = array();
        $data['all_index'] = $this->super_admin_model->select_all_index();
        $data['admin_maincontent'] = $this->load->view('admin/manage_index', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function manage_dokandarer_baki() {
        $data = array();
        $data['all_baki_list'] = $this->db->select('*')->from('tbl_dokandarer_baki')->join('tbl_baki', 'tbl_baki.dokandarer_id = tbl_dokandarer_baki.dokandarer_id')->get()->result();
        // $data['all_baki'] = $this->super_admin_model->select_all_baki();
        $data['admin_maincontent'] = $this->load->view('admin/manage_dokandarer_baki', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function save_order_book() {
        $data = array();
        $data['product_id'] = $this->input->post('product_id');
        $data['product_size'] = $this->input->post('product_size');
        $data['product_quantity'] = $this->input->post('product_quantity');
        $data['order_date'] = $this->input->post('order_date');
        $data['product_shop_price'] = $this->input->post('product_shop_price');
        $data['order_product_dealer_price'] = $this->input->post('order_product_dealer_price');

        $data['percentage'] = $data['product_shop_price'] - $data['order_product_dealer_price'];
        $data['amader_invest_taka'] = $data['product_quantity'] * $data['order_product_dealer_price'];
        $data['total_lav'] = $data['product_quantity'] * $data['percentage'];

        $data['dokandarer_total_price'] = $data['product_quantity'] * $data['product_shop_price'];

        // print_r($data);
        // exit();
        $this->super_admin_model->save_order_book_data($data);
        $sdata = array();
        $sdata['message'] = "Successfully Added Product";
        $this->session->set_userdata($sdata);
        redirect('super_admin/order_book');
    }

    public function save_dealer_product() {
        $data = array();
        $data['product_id'] = $this->input->post('product_id');
        $data['product_challan_no'] = $this->input->post('product_challan_no');
        $quantity = $data['product_quantity'] = $this->input->post('product_quantity');
        $dealer_price = $data['product_dealer_price'] = $this->input->post('product_dealer_price');
        $shop_price = $data['product_shop_price'] = $this->input->post('product_shop_price');

        $a = $shop_price - $dealer_price;
        $output = $quantity * $a;

        $data['product_dealer_lav_price'] = $output;

        $asd = $quantity * $dealer_price;

        $data['quantity_dealer_total_price'] = $asd;
        //$this->input->post('product_dealer_lav_price');
        $ay = $shop_price - $dealer_price;
        $data['pich_proti_dealer_lav'] = $ay;

        $this->super_admin_model->save_dealer_data($data);
        $sdata = array();
        $sdata['message'] = "Successfully Added Product";
        $this->session->set_userdata($sdata);
        redirect('super_admin/add_dealer_product');
    }

    public function update_product() {
        $data = array();
        $product_id = $this->input->post('product_id', true);

        $data['product_name'] = $this->input->post('product_name');
        $data['product_size'] = $this->input->post('product_size');
        // $data['product_quantity'] = $this->input->post('product_quantity');
        //  $data['product_dealer_price'] = $this->input->post('product_dealer_price');
        //   $data['product_shop_price'] = $this->input->post('product_shop_price');

        $this->super_admin_model->update_product_data($data, $product_id);
        redirect('super_admin/manage_customer_suprovat');
    }

    public function update_hiv_patient_linkage() {
        $data = array();
        $hiv_patient_id = $this->input->post('hiv_patient_id');
        $data['tb_screening_linkage_to_care'] = $this->input->post('tb_screening_linkage_to_care');
        $data['ipt_start'] = $this->input->post('ipt_start');
        $data['notify24hours'] = $this->input->post('notify24hours');
        $data['art_start'] = $this->input->post('art_start');

        $this->super_admin_model->update_product_data2($data, $hiv_patient_id);

        redirect('super_admin/manage_customer_suprovat');
    }

    public function update_treatment() {
        $data = array();
        $hiv_patient_id = $this->input->post('hiv_patient_id');
        $data['tv_screening_treatment_page'] = $this->input->post('tv_screening_treatment_page');
        $data['diabetes'] = $this->input->post('diabetes');
        $data['hypertension'] = $this->input->post('hypertension');
        $data['hypertension2'] = $this->input->post('hypertension2');
        $data['pregnancy'] = $this->input->post('pregnancy');
        $data['first_line_regimen'] = $this->input->post('first_line_regimen');
        $data['second_line_regimen'] = $this->input->post('second_line_regimen');
        $data['viral_load_due_annual'] = $this->input->post('viral_load_due_annual');
        $data['on_ipt'] = $this->input->post('on_ipt');
        $data['ipt_start_treatment'] = $this->input->post('ipt_start_treatment');

        $this->super_admin_model->update_product_data2($data, $hiv_patient_id);

        redirect('super_admin/manage_customer_suprovat');
    }

    public function update_consent_form() {

        $hiv_patient_id = $this->input->post('hiv_patient_id');

        $config['upload_path'] = './images/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = 9900;
        $config['max_width'] = 9900;
        $config['max_height'] = 9900;
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('image')) {
            $error = array('error' => $this->upload->display_errors());

            $this->load->view('super_admin/index', $error);
        } else {
            $config['source_image'] = $this->upload->upload_path . $this->upload->file_name;
            //print_r($config['source_image']);
//            exit();
            $fdata = $this->upload->data();
            $data['image'] = base_url() . $config['upload_path'] . $fdata['file_name'];
            $data['recent_test_result'] = $this->input->post('recent_test_result');
            //$data['file_image'] = $this->input->post('file_image');
            $data['next_test_date_consent'] = $this->input->post('next_test_date_consent');
            $data['no_index_contact'] = $this->input->post('no_index_contact');
//            print_r($data['image']);
//           exit();
            $this->super_admin_model->update_consent($data, $hiv_patient_id);

            redirect('super_admin/manage_customer_suprovat');
        }
    }

    public function update_awaiting_on_art() {
        $data = array();
        $hiv_patient_id = $this->input->post('hiv_patient_id');
        $data['presumptive'] = $this->input->post('presumptive');
        $data['notify_after_two_weeks'] = $this->input->post('notify_after_two_weeks');
        $data['reffered_admitted_hospital'] = $this->input->post('reffered_admitted_hospital');
        $data['not_ready_for_art'] = $this->input->post('not_ready_for_art');
        $data['refused'] = $this->input->post('refused');
        $data['drug_stock_out'] = $this->input->post('drug_stock_out');
        $data['others'] = $this->input->post('others');
        $data['specify_others'] = $this->input->post('specify_others');
//        $data['art_initiation'] = $this->input->post('art_initiation');

        $this->super_admin_model->update_awaiting_on_art($data, $hiv_patient_id);

        redirect('super_admin/manage_customer_suprovat');
    }

    public function update_testing() {
        $data = array();
        $hiv_patient_id = $this->input->post('hiv_patient_id');
        $data['test_refused'] = $this->input->post('test_refused');
        $data['test_details'] = $this->input->post('test_details');

        $this->super_admin_model->update_product_data3($data, $hiv_patient_id);

        redirect('super_admin/manage_customer_suprovat');
    }

    public function update_defaulter() {
        $data = array();
        $hiv_patient_id = $this->input->post('hiv_patient_id');
        $data['tb_screening_defaulter'] = $this->input->post('tb_screening_defaulter');
        $data['art_re_initiation'] = $this->input->post('art_re_initiation');

        $this->super_admin_model->update_defaulter($data, $hiv_patient_id);

        redirect('super_admin/manage_customer_suprovat');
    }

    public function update_dealer_product() {
        $data = array();
        $dealer_product_id = $this->input->post('dealer_product_id');
        $data['product_id'] = $this->input->post('product_id');
        $data['product_challan_no'] = $this->input->post('product_challan_no');
        // $data['product_quantity'] = $this->input->post('product_quantity');
        // $data['product_dealer_price'] = $this->input->post('product_dealer_price');
        //   $data['product_shop_price'] = $this->input->post('product_shop_price');
        //   $data['product_dealer_lav_price'] = $this->input->post('product_dealer_lav_price');
        $quantity = $data['product_quantity'] = $this->input->post('product_quantity');
        $dealer_price = $data['product_dealer_price'] = $this->input->post('product_dealer_price');
        $shop_price = $data['product_shop_price'] = $this->input->post('product_shop_price');

        $a = $shop_price - $dealer_price;
        $output = $quantity * $a;

        $data['product_dealer_lav_price'] = $output;

        $asd = $quantity * $dealer_price;
        $data['quantity_dealer_total_price'] = $asd;
        $ay = $shop_price - $dealer_price;
        $data['pich_proti_dealer_lav'] = $ay;

        // print_r($data);
        //  exit();
        $this->super_admin_model->update_dealer_product($data, $dealer_product_id);
        // $sdata = array();
        // $sdata['message'] = "Successfully Updated Dealer Product";
        // $this->session->set_userdata($sdata);
        redirect('super_admin/manage_dealer_product');
    }

    public function delete_dealer_product($dealer_product_id) {
        $this->super_admin_model->delete_dealer_product_id($dealer_product_id);
        redirect('super_admin/manage_dealer_product');
    }

    public function update_order_book() {
        $data = array();
        $order_book_id = $this->input->post('order_book_id');
        $data['product_id'] = $this->input->post('product_id');
        $data['product_size'] = $this->input->post('product_size');
        $data['product_quantity'] = $this->input->post('product_quantity');
        $data['order_product_dealer_price'] = $this->input->post('order_product_dealer_price');
        $data['product_shop_price'] = $this->input->post('product_shop_price');

        $data['percentage'] = $data['product_shop_price'] - $data['order_product_dealer_price'];
        $data['amader_invest_taka'] = $data['product_quantity'] * $data['order_product_dealer_price'];
        $data['total_lav'] = $data['product_quantity'] * $data['percentage'];

        $data['dokandarer_total_price'] = $data['product_quantity'] * $data['product_shop_price'];

        // $data['product_dealer_lav_price'] = $this->input->post('product_dealer_lav_price');
        // print_r($data);
        //  exit();
        $this->super_admin_model->update_order_book_id($data, $order_book_id);
        // $sdata = array();
        // $sdata['message'] = "Successfully Updated Dealer Product";
        // $this->session->set_userdata($sdata);
        redirect('super_admin/manage_order_book');
    }

    public function update_dokandar() {
        $data = array();
        $dokandarer_id = $this->input->post('dokandarer_id');

        $data['shop_name'] = $this->input->post('shop_name');
        $data['maliker_name'] = $this->input->post('maliker_name');
        $data['market_name'] = $this->input->post('market_name');
        $data['mobile_number'] = $this->input->post('mobile_number');
        // $data['product_dealer_lav_price'] = $this->input->post('product_dealer_lav_price');
        // print_r($data);
        //  exit();
        $this->super_admin_model->update_dokandar_id($data, $dokandarer_id);
        // $sdata = array();
        // $sdata['message'] = "Successfully Updated Dealer Product";
        // $this->session->set_userdata($sdata);
        redirect('super_admin/manage_dokandar');
    }

    public function update_dokandarer_baki() {
        $data = array();
        $baki_id = $this->input->post('baki_id');

        $data['memo_serial'] = $this->input->post('memo_serial');
        $data['total_price'] = $this->input->post('total_price');
        $data['joma'] = $this->input->post('joma');
        //$data['mobile_number'] = $this->input->post('mobile_number');
        // $data['product_dealer_lav_price'] = $this->input->post('product_dealer_lav_price');
        // print_r($data);
        //  exit();
        $this->super_admin_model->update_dokandar_baki_id($data, $baki_id);
        // $sdata = array();
        // $sdata['message'] = "Successfully Updated Dealer Product";
        // $this->session->set_userdata($sdata);
        redirect('super_admin/manage_dokandarer_baki');
    }

    public function manage_customer_suprovat() {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['all_product_details'] = $this->super_admin_model->select_all_category();
        $data['admin_maincontent'] = $this->load->view('admin/manage_customer', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function manage_dealer_product() {
        $data = array();
        $data['all_dealer_product_details'] = $this->super_admin_model->select_all_dealer_product();
        $data['admin_maincontent'] = $this->load->view('admin/manage_dealer_product', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function manage_order_book() {
        $data = array();
        $data['all_order_details'] = $this->super_admin_model->select_all_order_product();
        $data['admin_maincontent'] = $this->load->view('admin/manage_order_book', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function edit_patient($hiv_patient_id) {
        $data = array();
        $data['patient_info'] = $this->super_admin_model->select_patient_by_id($hiv_patient_id);
        $data['admin_maincontent'] = $this->load->view('admin/edit_patient', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function edit_dokandar($dokandarer_id) {
        $data = array();
        $data['dokandar_info'] = $this->super_admin_model->select_dokandar_info_by_id($dokandarer_id);
        $data['admin_maincontent'] = $this->load->view('admin/edit_dokandar', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function edit_dokandarer_baki($baki_id) {
        $data = array();
        $data['dokandar_baki_info'] = $this->super_admin_model->select_dokandar_baki_info_by_id($baki_id);
        // print_r($data['dokandar_baki_info']);
        // exit();

        $data['get_dokandar'] = $this->db->select('*')->from('tbl_baki')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/edit_dokandar_baki', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function edit_dealer_product($dealer_product_id) {
        $data = array();
        $data['dealer_product_info'] = $this->super_admin_model->select_all_dealer_product_by_id($dealer_product_id);
        $data['get_product'] = $this->db->select('*')->from('tbl_product')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/edit_dealer_product', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function edit_user($admin_id) {
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['product_info'] = $this->super_admin_model->select_all_user_by_id($admin_id);
        //$data['get_product'] = $this->db->select('*')->from('tbl_product')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/edit_user', $data, true);
        $this->load->view('admin/admin_master', $data);
    }
    public function add_roll($admin_id){
        $data = array();
        $data['notification'] = $this->super_admin_model->select_all_category();
        $data['product_info'] = $this->super_admin_model->select_all_user_by_id($admin_id);
        //$data['get_product'] = $this->db->select('*')->from('tbl_product')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/add_roll', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function edit_order_book_product($order_book_id) {
        $data = array();
        $data['order_book_info'] = $this->super_admin_model->select_order_book_by_id($order_book_id);
        $data['get_all_order_book'] = $this->db->select('*')->from('tbl_dealer_product')->join('tbl_product', 'tbl_product.product_id = tbl_dealer_product.product_id')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/edit_order_book', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function delete_suprovat_customer_details($hiv_patient_id) {
        $this->super_admin_model->delete_patient_id($hiv_patient_id);
        redirect('super_admin/manage_customer_suprovat');
    }

    public function delete_user($admin_id) {
        $this->super_admin_model->delete_user_id2($admin_id);
        redirect('super_admin/manage_user');
    }

    public function delete_index_user($tbl_index_id) {
        $this->super_admin_model->delete_index_id2($tbl_index_id);
        redirect('super_admin/manage_index');
    }

    public function delete_dokandar_details($dokandarer_id) {
        $this->super_admin_model->delete_dokandar_id($dokandarer_id);
        redirect('super_admin/manage_dokandar');
    }

    public function delete_dokandarer_baki($baki_id) {
        $this->super_admin_model->delete_dokandarer_baki($baki_id);
        redirect('super_admin/manage_dokandarer_baki');
    }

    public function order_book() {
        $data = array();
        $data['get_order'] = $this->db->select('*')->from('tbl_dealer_product')->join('tbl_product', 'tbl_product.product_id = tbl_dealer_product.product_id')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/order_book', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function delete_order_book($order_book_id) {
        $this->super_admin_model->delete_order_book_id($order_book_id);
        redirect('super_admin/manage_order_book');
    }

    public function print_area1() {
        $data = array();
        //$data['all_customer_details'] = $this->super_admin_model->select_all_category();
        $data['all_order_by_date'] = $this->db->select('*')->from('tbl_order_book')->join('tbl_product', 'tbl_product.product_id = tbl_order_book.product_id')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/print_area1', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function add_kisti_area1() {
        $data = array();
        //  $data['all_customer_details'] = $this->super_admin_model->select_all_category();
        //  $data['all_customer_details'] = $this->db->select('*')->from('tbl_customer')->get()->result();
        $data['all_product_details'] = $this->super_admin_model->select_all_category();

        //$data['get_users'] = $this->db->select('*')->from('tbl_customer')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/add_kisti_soncoy', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function add_kisti_soncoy_area_2() {
        $data = array();
        //  $data['all_customer_details'] = $this->super_admin_model->select_all_category();
        //$data['get_users'] = $this->db->select('*')->from('tbl_customer')->where('customer_action',2)->get()->result();
        $data['get_users'] = $this->db->select('*')->from('tbl_customer')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/add_kisti_soncoy_area_2', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function save_order() {

        $product_name = $this->input->post('product_name[]');
        $product_size = $this->input->post('product_size[]');
        $product_quantity = $this->input->post('product_quantity[]');
        $product_id = $this->input->post('product_id[]');
        $kisti = $this->input->post('product_quantity[]');
        $soncoy = $this->input->post('soncoy[]');
        $area = $this->input->post('area[]');

        for ($i = 0; $i < count($client_id_no); $i++) {

            $data1 = array(
                'customer_name' => $customer_name[$i],
                'address' => $address[$i],
                'client_id_no' => $client_id_no[$i],
                'customer_id' => $customer_id[$i],
                'kisti' => $kisti[$i],
                'area' => $area[$i],
                'soncoy' => $soncoy[$i]
            );

            $query = $this->user_model->insertKisty($data1);
        }

        if ($query) {
            $sdata = array();
            $sdata['message'] = "Successfully added your data";
            $this->session->set_userdata($sdata);
            redirect('super_admin/add_kisti_area1');
        } else {
            echo "error";
        }

        //}//for
    }

    public function save_kisty() {

        $customer_name = $this->input->post('customer_name[]');
        $address = $this->input->post('address[]');
        $client_id_no = $this->input->post('client_id_no[]');
        $customer_id = $this->input->post('customer_id[]');
        $kisti = $this->input->post('kisti[]');
        $soncoy = $this->input->post('soncoy[]');
        $area = $this->input->post('area[]');

        for ($i = 0; $i < count($client_id_no); $i++) {

            $data1 = array(
                'customer_name' => $customer_name[$i],
                'address' => $address[$i],
                'client_id_no' => $client_id_no[$i],
                'customer_id' => $customer_id[$i],
                'kisti' => $kisti[$i],
                'area' => $area[$i],
                'soncoy' => $soncoy[$i]
            );

            $query = $this->user_model->insertKisty($data1);
        }

        if ($query) {
            $sdata = array();
            $sdata['message'] = "Successfully added your data";
            $this->session->set_userdata($sdata);
            redirect('super_admin/add_kisti_area1');
        } else {
            echo "error";
        }

        //}//for
    }

    public function save_kisty_area2() {

        $customer_name = $this->input->post('customer_name[]');
        $address = $this->input->post('address[]');
        $client_id_no = $this->input->post('client_id_no[]');
        $customer_id = $this->input->post('customer_id[]');
        $kisti = $this->input->post('kisti[]');
        $soncoy = $this->input->post('soncoy[]');
        $area = $this->input->post('area[]');

        for ($i = 0; $i < count($client_id_no); $i++) {

            $data1 = array(
                'customer_name' => $customer_name[$i],
                'address' => $address[$i],
                'client_id_no' => $client_id_no[$i],
                'customer_id' => $customer_id[$i],
                'kisti' => $kisti[$i],
                'area' => $area[$i],
                'soncoy' => $soncoy[$i]
            );

            $query = $this->user_model->insertKisty($data1);
        }

        if ($query) {
            $sdata = array();
            $sdata['message'] = "Successfully added your data";
            $this->session->set_userdata($sdata);
            redirect('super_admin/add_kisti_soncoy_area_2');
        } else {
            echo "error";
        }

        //}//for
    }

    public function add_all_kisti() {
        $data = array();

        $data['get_users'] = $this->db->select('*')->from('tbl_kisti_soncoy')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/add_all_kisti', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function save_all_kisty() {

        $customer_name = $this->input->post('customer_name[]');
        $address = $this->input->post('address[]');
        $client_id_no = $this->input->post('client_id_no[]');
        $customer_id = $this->input->post('customer_id[]');
        $kisti = $this->input->post('kisti[]');
        $soncoy = $this->input->post('soncoy[]');
        $area = $this->input->post('area[]');

        for ($i = 0; $i < count($client_id_no); $i++) {

            $data1 = array(
                'customer_name' => $customer_name[$i],
                'address' => $address[$i],
                'client_id_no' => $client_id_no[$i],
                'customer_id' => $customer_id[$i],
                'kisti' => $kisti[$i],
                'area' => $area[$i],
                'soncoy' => $soncoy[$i]
            );

            $query = $this->user_model->insertallKisty($data1);
        }

        if ($query) {
            $sdata = array();
            $sdata['message'] = "Successfully added your data";
            $this->session->set_userdata($sdata);
            redirect('super_admin/add_all_kisti');
        } else {
            echo "error";
        }
    }

    public function manage_kisti_soncoy() {
        $data = array();
        // $date= date("Y-m-d");
        //  $data['get_data'] = $this->super_admin_model->select_kisti_concoy_by_date($date);
        // $data['get_data'] = $this->db->select('*')->from('tbl_customer')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/manage_kisti_soncoy', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function manage_customer_area2() {
        $data = array();
        $data['all_customer_details'] = $this->super_admin_model->select_all_category();
        $data['admin_maincontent'] = $this->load->view('admin/manage_customer_area2', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function manage_area1() {
        $data = array();
        $data['all_customer_details'] = $this->super_admin_model->select_all_category();
        $data['admin_maincontent'] = $this->load->view('admin/manage_area1', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function manage_area2() {
        $data = array();
        $data['all_customer_details'] = $this->super_admin_model->select_all_category();
        $data['admin_maincontent'] = $this->load->view('admin/manage_area2', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function delete_daily_kisti_soncoy_data1() {
        // $this->db->select('*')->from('tbl_customer')->get()->result();
        $this->db->where('area', 1);
        //$this->db->where('area',2);
        $this->db->delete('tbl_kisti_soncoy');

        //DELETE FROM tbl_kisti_soncoy WHERE `area`='1';
        redirect('super_admin');
    }

    public function delete_daily_kisti_soncoy_data2() {
        // $this->db->select('*')->from('tbl_customer')->get()->result();
        $this->db->where('area', 2);
        //$this->db->where('area',2);
        $this->db->delete('tbl_kisti_soncoy');

        //DELETE FROM tbl_kisti_soncoy WHERE `area`='1';
        redirect('super_admin');
    }

    public function daily_hisab_area_1() {
        $data = array();
        $data['daily_hisab_area_1'] = $this->db->select('*')->from('daily_hisab')->get()->result();

        $data['admin_maincontent'] = $this->load->view('admin/daily_hisab', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function daily_hisab_area_2() {
        $data = array();
        $data['daily_hisab_area_2'] = $this->db->select('*')->from('daily_hisab')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/daily_hisab2', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function daily_hisab_print_1() {
        $data = array();
        $data['daily_hisab_print_1'] = $this->db->select('*')->from('daily_hisab')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/daily_hisab_print', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function daily_hisab_print_2() {
        $data = array();
        $data['daily_hisab_print_2'] = $this->db->select('*')->from('daily_hisab')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/daily_hisab_print2', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function save_daily_hisab() {
        //     $data = array();
        //     $data['office_khoroj'] = $this->input->post('office_khoroj');
        //     $data['poribohon_khoroj'] = $this->input->post('poribohon_khoroj');
        //     $data['bibidh'] = $this->input->post('bibidh');
        //     $data['total_aday'] = $this->input->post('total_aday');
        //   //  $this->super_admin_model->save_daily_hisab_data($data);
        //     $data['from_address']='chayan.roy111@gmail.com';
        //     $data['to_address']='chayans.roy1@gmail.com';
        //     $data['subject']='suprovat_subject';
        //     $this->mailer_model->sendEmail($data,'daily_email_hisab');
        //     //$sdata = array();
        //     //$sdata['message'] = "Successfully added your data";
        //     //$this->session->set_userdata($sdata);
        //     redirect('super_admin/add_all_daily_hisab');

        $data = array();

        $data['office_khoroj'] = $this->input->post('office_khoroj');
        $data['poribohon_khoroj'] = $this->input->post('poribohon_khoroj');
        $data['bibidh'] = $this->input->post('bibidh');
        $data['total_aday'] = $this->input->post('total_aday');
        $this->super_admin_model->save_daily_hisab_data($data);
        $sdata = array();
        $sdata['message'] = "Successfully added your data";
        $this->session->set_userdata($sdata);
        //email send
        $mdata = array();
        $mdata['from_address'] = 'chayan.roy111@gmail.com';
        $mdata['to_address'] = 'chayans.roy1@gmail.com';
        $mdata['subject'] = 'suprovat email subject';

        $mdata['office_khoroj'] = $this->input->post('office_khoroj', true);
        $mdata['poribohon_khoroj'] = $this->input->post('poribohon_khoroj', true);
        $mdata['bibidh'] = $this->input->post('bibidh', true);
        $mdata['total_aday'] = $this->input->post('total_aday', true);

        $this->mailer_model->sendEmail($mdata, 'daily_email_hisab');
        // $mdata = array();
        // $mdata['message'] = "Successfully added your data";
        // $this->session->set_userdata($sdata);

        redirect('super_admin/add_all_daily_hisab');
    }

    public function update_daily_hisab() {
        $data = array(
            'id_no' => $this->input->post('id_no'),
            'poriman' => $this->input->post('poriman'),
            'office_khoroj' => $this->input->post('office_khoroj'),
            'beton_vata' => $this->input->post('beton_vata'),
            'poribohon_khoroj' => $this->input->post('poribohon_khoroj'),
            'bibidh' => $this->input->post('bibidh'),
            'total_aday' => $this->input->post('total_aday'),
            'new_customer_name' => $this->input->post('new_customer_name'),
            'new_customer_id' => $this->input->post('new_customer_id'),
            'new_customer_fee' => $this->input->post('new_customer_fee'),
            'area' => $this->input->post('area')
        );
        $this->super_admin_model->update_daily_hisab_data($data);
        $sdata = array();
        $sdata['message'] = "Successfully added your data";
        $this->session->set_userdata($sdata);
        redirect('super_admin/daily_hisab_area_1');
        // $this->cart->update($data);
        // redirect('checkout/show_cart');
    }

    public function update_user() {
        $admin_id = $this->input->post('admin_id', true);
        $data = array(
            'admin_name' => $this->input->post('admin_name'),
            'user_identify_number' => $this->input->post('user_identify_number'),
            'phone_number' => $this->input->post('phone_number'),
            'company_number' => $this->input->post('company_number'),
            'designation' => $this->input->post('designation'),
            'admin_email_address' => $this->input->post('admin_email_address'),
            'password' => $this->input->post('password'),
            'access_label' => $this->input->post('access_label'),
            'location' => $this->input->post('location')
        );
        $this->super_admin_model->update_user($data, $admin_id);
        $sdata = array();
        $sdata['message'] = "Successfully Updated your data";
        $this->session->set_userdata($sdata);
        redirect('super_admin/manage_user');
        // $this->cart->update($data);
        // redirect('checkout/show_cart');
    }

    public function update_single_user() {
        $admin_id = $this->input->post('admin_id', true);
        $data = array(
            'admin_name' => $this->input->post('admin_name'),
            'user_identify_number' => $this->input->post('user_identify_number'),
            'phone_number' => $this->input->post('phone_number'),
            'company_number' => $this->input->post('company_number'),
            //'designation' => $this->input->post('designation'),
//            'admin_email_address' => $this->input->post('admin_email_address'),
            'password' => $this->input->post('password'),
            'location' => $this->input->post('location')
        );
        $this->super_admin_model->update_single_user($data, $admin_id);
        $sdata = array();
        $sdata['message'] = "Successfully Updated your data";
        $this->session->set_userdata($sdata);
        redirect('super_admin/index');
        // $this->cart->update($data);
        // redirect('checkout/show_cart');
    }

    public function update_patient() {

        $hiv_patient_id = $this->input->post('hiv_patient_id', true);
        $data = array(
            'name' => $this->input->post('name'),
            'gender' => $this->input->post('gender'),
            'identifynumber' => $this->input->post('identifynumber'),
            'patient_age' => $this->input->post('patient_age'),
            'patientphonenumber' => $this->input->post('patientphonenumber'),
            'address' => $this->input->post('address'),
            'kinname' => $this->input->post('kinname'),
            'kinphonenumber' => $this->input->post('kinphonenumber'),
            'relationship' => $this->input->post('relationship'),
            'patient_value' => $this->input->post('patient_value'),
            'treatment_start_date' => $this->input->post('treatment_start_date'),
            'hiv_status' => $this->input->post('hiv_status'),
            'last_hiv_test_date' => $this->input->post('last_hiv_test_date'),
            'kinaddress' => $this->input->post('kinaddress')
        );
        $this->super_admin_model->update_patient($data, $hiv_patient_id);
        $sdata = array();
        $sdata['message'] = "Successfully Updated your data";
        $this->session->set_userdata($sdata);
        redirect('super_admin/manage_customer_suprovat');
        // $this->cart->update($data);
        // redirect('checkout/show_cart');
    }

    public function update_daily_hisab_2() {
        $data = array(
            'id_no' => $this->input->post('id_no'),
            'poriman' => $this->input->post('poriman'),
            'office_khoroj' => $this->input->post('office_khoroj'),
            'beton_vata' => $this->input->post('beton_vata'),
            'poribohon_khoroj' => $this->input->post('poribohon_khoroj'),
            'bibidh' => $this->input->post('bibidh'),
            'total_aday' => $this->input->post('total_aday'),
            'new_customer_name' => $this->input->post('new_customer_name'),
            'new_customer_id' => $this->input->post('new_customer_id'),
            'new_customer_fee' => $this->input->post('new_customer_fee'),
            'area' => $this->input->post('area')
        );
        $this->super_admin_model->update_daily_hisab_data_2($data);
        $sdata = array();
        $sdata['message'] = "Successfully added your data";
        $this->session->set_userdata($sdata);
        redirect('super_admin/daily_hisab_area_2');
        // $this->cart->update($data);
        // redirect('checkout/show_cart');
    }

    public function active_customer($product_id) {

        $this->super_admin_model->publish_customer_by_id($product_id);
        redirect('super_admin/manage_customer_suprovat');
    }

    public function deactive_customer($product_id) {

        $this->super_admin_model->unpublish_customer_by_id($product_id);
        redirect('super_admin/manage_customer_suprovat');
    }

    public function add_all_daily_hisab() {
        $data = array();

        // $data['get_users'] = $this->db->select('*')->from('tbl_kisti_soncoy')->get()->result();
        $data['daily_hisab_area_1'] = $this->db->select('*')->from('daily_hisab')->get()->result();
        $data['admin_maincontent'] = $this->load->view('admin/add_all_hisab_main', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function view_all_daily_hisab() {
        $data = array();
        $data['all_daily_hisab_db'] = $this->super_admin_model->select_all_daily_hisab();
        $data['admin_maincontent'] = $this->load->view('admin/view_all_daily_hisab', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function view_customer($hiv_patient_id) {
        $data = array();

        $data['customer_info'] = $this->super_admin_model->select_customer_data_by_id($hiv_patient_id);
        $data['notification'] = $this->super_admin_model->select_all_category();
        //$data['customer_info'] = $this->super_admin_model->select_customer_by_id($hiv_patient_id);
//        echo '<pre> ff';
//        print_r($data['customer_info']);
        $data['admin_maincontent'] = $this->load->view('admin/view_customer', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function view_dokandar($dokandarer_id) {
        $data = array();

        $data['dokaner_daily_entry'] = $this->super_admin_model->select_dokandarer_baki_by_id($dokandarer_id);

        $data['customer_info'] = $this->super_admin_model->select_customer_by_id($dokandarer_id);
        $data['admin_maincontent'] = $this->load->view('admin/view_dokandar_details', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function view_dealer_product_details($product_id) {
        $data = array();

        $data['all_order_product_list_price'] = $this->super_admin_model->all_order_product_list_price_by_id($product_id);

        $data['dealer_khuchra_order'] = $this->super_admin_model->dealer_khuchra_order_by_id($product_id);
        $data['dealer_entry_product_details'] = $this->super_admin_model->dealer_entry_product_details_by_id($product_id);

        $data['dealer_entry_product_details_by_result'] = $this->super_admin_model->dealer_entry_product_details_by_result($product_id);

        $data['dealer_product_details'] = $this->super_admin_model->select_dealer_product_by_id($product_id);
        $data['tbl_dealer_product_by_id'] = $this->super_admin_model->tbl_dealer_product_by_id($product_id);
        $data['admin_maincontent'] = $this->load->view('admin/view_dealer_product_details', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function manage_all_kisti() {
        $data = array();
        $data['all_customer_details'] = $this->super_admin_model->select_all_customer_kisti();
        $data['admin_maincontent'] = $this->load->view('admin/manage_all_kisti', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function delete_customer_kisti_main_section($serial_no) {
        // $this->db->select('*')->from('tbl_customer')->get()->result();
        $this->db->where('serial_no', $serial_no);
        //$this->db->where('area',2);
        $this->db->delete('tbl_customer_main_data');

        //DELETE FROM tbl_kisti_soncoy WHERE `area`='1';
        redirect('super_admin/manage_all_kisti');
    }

    public function edit_customer_kisti_main_section($serial_no) {
        $data = array();
        $data['customer_kisti_sonchoy'] = $this->super_admin_model->select_customer_kisti_sonchoy_id($serial_no);
        $data['admin_maincontent'] = $this->load->view('admin/edit_kisti_sonchoy', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function share_holder() {
        $data = array();
        $data['all_share_holder'] = $this->super_admin_model->select_all_share_holder();
        $data['admin_maincontent'] = $this->load->view('admin/share_holder', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function beton_vata() {
        $data = array();
        //$data['all_share_holder'] = $this->super_admin_model->select_all_share_holder();
        $data['admin_maincontent'] = $this->load->view('admin/beton_vata', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function save_beton_vata() {
        $data = array();
        $data['employee_name'] = $this->input->post('employee_name');
        $data['employee_id'] = $this->input->post('employee_id');
        $data['employee_designation'] = $this->input->post('employee_designation');
        $data['mobile_no'] = $this->input->post('mobile_no');
        $data['taka'] = $this->input->post('taka');
        $data['note'] = $this->input->post('note');

        $this->super_admin_model->save_beton_vata($data);
        $sdata = array();
        $sdata['message'] = "Successfully added your data";
        $this->session->set_userdata($sdata);
        redirect('super_admin/beton_vata');
    }

    public function manage_beton_vata() {
        $data = array();
        $data['all_beton_vata'] = $this->super_admin_model->select_all_beton_vata();
        $data['admin_maincontent'] = $this->load->view('admin/manage_beton_vata', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function add_dps() {
        $data = array();
        //$data['all_share_holder'] = $this->super_admin_model->select_all_share_holder();
        $data['admin_maincontent'] = $this->load->view('admin/add_dps', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function save_dps() {
        $data = array();
        $data['c_name'] = $this->input->post('c_name');
        $data['dps_id'] = $this->input->post('dps_id');
        $data['c_nid'] = $this->input->post('c_nid');
        $data['number'] = $this->input->post('number');
        $data['dps_name'] = $this->input->post('dps_name');
        $data['start_date'] = $this->input->post('start_date');
        $data['end_date'] = $this->input->post('end_date');
        $data['address'] = $this->input->post('address');

        $data['dps_amount'] = $this->input->post('dps_amount');
        $data['dps_year'] = $this->input->post('dps_year');
        $data['dps_profit'] = $this->input->post('dps_profit');

        $this->super_admin_model->save_dps($data);
        $sdata = array();
        $sdata['message'] = "Successfully added your data";
        $this->session->set_userdata($sdata);
        redirect('super_admin/add_dps');
    }

    public function manage_dps() {
        $data = array();
        $data['all_dps'] = $this->super_admin_model->select_all_dps();
        $data['admin_maincontent'] = $this->load->view('admin/manage_dps', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function chart() {
        $data = array();
        $data['all_beton_vata'] = $this->super_admin_model->select_all_beton_vata();
        // $data['all_share_holder'] = $this->super_admin_model->select_all_share_holder();
        $data['admin_maincontent'] = $this->load->view('admin/chart', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function skim() {
        $data = array();
        //$data['all_share_holder'] = $this->super_admin_model->select_all_share_holder();
        $data['admin_maincontent'] = $this->load->view('admin/skim', $data, TRUE);
        $this->load->view('admin/admin_master', $data);
    }

    public function update_customer_kisti_sonchoy($serial_no) {
        $serial_no = $this->input->post('serial_no', true);
        $data = array(
            //'id_no'   => $this->input->post('serial_no'),
            'kisti' => $this->input->post('kisti'),
            'soncoy' => $this->input->post('soncoy')
        );
        $this->super_admin_model->update_kisti_soncoy($data, $serial_no);
        $sdata = array();

        redirect('super_admin/manage_all_kisti');
    }

    public function everydaytask() {
        $data = array();
        $data['admin_maincontent'] = $this->load->view('admin/everydaytask', $data, true);
        $this->load->view('admin/admin_master', $data);
    }

    public function save_everydaytask() {

        /*
         * file upload area start -------------
         */
        $data = array();
        $sdata = array();
        $fdata = array();
        $error = '';
        if ($_FILES['image']['name']) {
            $config['upload_path'] = 'images/shit_image/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '2000';
            $config['max_width'] = '2024';
            $config['max_height'] = '968';

            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('image')) {
                $error = $this->upload->display_errors();
                $sdata['message'] = $error;
                $this->session->set_userdata($sdata);
                redirect('super_admin/everydaytask');
            } else {
                //image resize
                $config['source_image'] = $this->upload->upload_path . $this->upload->file_name;
                $config['maintain_ratio'] = FALSE;
                $config['width'] = 740;
                $config['height'] = 540;
                $this->load->library('image_lib', $config);

                if (!$this->image_lib->resize()) {
                    $this->session->set_flashdata('message', $this->image_lib->display_errors('', ''));
                } else {
                    $fdata = $this->upload->data();
                    $data['image'] = base_url() . $config['upload_path'] . $fdata['file_name'];
                }
            }
        } else {

            $sdata['message'] = "Images/file not selected;";
            $this->session->set_userdata($sdata);
            redirect('super_admin/everydaytask');
        }
        /*
         * file upload area end here--------------
         */
        $data['note'] = $this->input->post('note', true);
        $this->super_admin_model->save_everyday_task($data);
        $sdata['sms'] = "successfully Added Image";
        $this->session->set_userdata($sdata);
        redirect('super_admin/everydaytask');
    }

}
