<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
 
class Admin extends CI_Controller {
    public function __construct() {
        parent::__construct();
        error_reporting(0);
         $admin_id=$this->session->userdata('admin_id');
        if($admin_id != NULL)
        {
            redirect('super_admin');
        }
         $this->load->model('admin_model', 'a_model');
   }
// public function __construct(){
//         parent:: __construct(); 
        
//         $this->load->model("user_model");
//         $this->load->helper('user_helper'); 
//     }
   
    public function index() {
        $this->load->view('admin/login');
    }

//    public function admin_login_check() {
//
//        $admin_email_address = $this->input->post('admin_email_address');
//        $password = $this->input->post('password');
//        $mysql_info = $this->a_model->check_admin_login_info($admin_email_address, $password);
//
//        $data = array();
//        if ($mysql_info) {
//            $data['admin_id']=$mysql_info->admin_id;
//            $data['admin_name']=$mysql_info->admin_name;
//            $data['permission']=$mysql_info->permission;
//            $this->session->set_userdata($data);
//            redirect('super_admin');
//        } else {
//            $sdata=array();
//            $sdata['sms']="Your email or password invalied";
//            $this->session->set_userdata($sdata);
//            redirect('admin');
//        }
//    }

}
