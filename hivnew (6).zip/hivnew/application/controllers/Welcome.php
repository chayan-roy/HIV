<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {
    
	public function index()
	{
            $data=array();
            $data['home']=true;
            $data['main_content']=$this->load->view('home_content',$data,TRUE);
            $this->load->view('master',$data);
	}
          public function admin_login_check() {

        $admin_email_address = $this->input->post('admin_email_address');
        $password = $this->input->post('password');
        $mysql_info = $this->admin_model->check_admin_login_info($admin_email_address, $password);

        $data = array();
        if ($mysql_info) {
            $data['admin_id']=$mysql_info->admin_id;
            $data['admin_name']=$mysql_info->admin_name;
            $data['access_label']=$mysql_info->access_label;
            $this->session->set_userdata($data);
            redirect('super_admin');
        } else {
            $sdata=array();
            $sdata['sms']="Your email or password invalied";
            $this->session->set_userdata($sdata);
            redirect('welcome');
        }
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */