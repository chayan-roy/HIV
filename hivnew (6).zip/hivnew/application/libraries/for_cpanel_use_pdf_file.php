<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once(dirname(__FILE__) . '/dompdf/autoload.inc.php');
use Dompdf\Dompdf; // local server er somoy ei line removed korte hobe
class Pdf
{
    function createPDF($html, $filename='', $download=TRUE, $paper='A4', $orientation='portrait'){
        
        $dompdf = new Dompdf(); //local server er somoy ei line removed korte hobe
         //$dompdf = new Dompdf\DOMPDF(); //local server er somoy eta on korte hobe..
        $dompdf->load_html($html);
       // $dompdf->load_html_file($html)->load_html($html);
        $dompdf->set_paper($paper, $orientation);
        $dompdf->render();
        if($download)
            $dompdf->stream($filename.'.pdf', array('Attachment' => 1));
        else
            $dompdf->stream($filename.'.pdf', array('Attachment' => 0));
            

    }
}
?>
